package com.xti.nexus_sih

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
