import 'package:flutter/material.dart';
class SilverPage extends StatefulWidget {
  @override
  _SilverPageState createState() => _SilverPageState();
}

class _SilverPageState extends State<SilverPage> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
